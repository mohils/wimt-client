---
title: footer
footerLogo: /upload/images/footer-logo.svg
pages:
  page1: Home
  page2: Team
  page3: Sponsors
contact:
  email: contact@winningimpact.com
  phone: +46 10 641 49 90
co-footer:
  leftText: ©2022 Winning Impact AB
  rightText1: Privacy Policy
  rightText2: Term of Service
---
