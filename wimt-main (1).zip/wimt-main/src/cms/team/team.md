---
title: Team
header:
  headerTitleWithWhiteColor1: The
  headerTitleWithLogoColor: Winning
  headerTitleWithWhiteColor2: Team
  headerText: We are proud to be able to say that we literally have the greatest team. A Winning team that's brought together to make an Impact.
  headerImage: /upload/images/top-header-img-team.svg
ourTeam:
  ourTeamHeaderBtn1: Management
  ourTeamHeaderBtn2: The board
  ourTeamWorker5Image: /upload/images/worker-5.svg
  ourTeamHeaderBtn3: Advisors & Investors
  ourTeamWorker4Image: /upload/images/worker-4.svg
  ourTeamWorker5SportsImage: /upload/images/waterpolo.svg
  ourTeamWorker3Image: /upload/images/worker-3.svg
  ourTeamWorker4SportsImage: /upload/images/football.svg
  ourTeamWorker3SportsImage: /upload/images/hockey.svg
  ourTeamWorker2Image: /upload/images/worker-2.svg
  ourTeamWorker1Image: /upload/images/worker-1.svg
  ourTeamWorker2SportsImage: /upload/images/programming.svg
  ourTeamWorker1SportsImage: /upload/images/volleyball.svg
  ourTeamWorker1Position: Co-founder & CTO
  ourTeamWorker2Position: Co-founder & CEO
  ourTeamWorker1SportsName: Volleyball
  ourTeamWorker2SportsName: Programming
  ourTeamWorker3Position: Co-founder & CEO
  ourTeamWorker1Name: Rustan Hakansson
  ourTeamWorker3SportsName: Hockey
  ourTeamWorker1SportsHeader: Favorite sport
  ourTeamWorker4Position: CFO
  ourTeamWorker2Name: Fredik Niemelä
  ourTeamHeader: Our Team
  ourTeamWorker3Name: Sebastian Lundgren
  ourTeamWorker4SportsName: Football
  ourTeamWorker2SportsHeader: Favorite sport
  ourTeamWorker5Position: Co-founder & HSC
  ourTeamWorker4Name: Krister Cullberg
  ourTeamWorker3SportsHeader: Favorite sport
  ourTeamWorker5SportsName: Waterpolo
  ourTeamWorker5Name: Alicia Pierrou
  ourTeamWorker4SportsHeader: Favorite sport
  ourTeamWorker5SportsHeader: Favorite sport
bannerBg:
  bannerBgQuote: Our team is world leading experts, and our different characteristics and areas of knowledge truly makes us a winning team.
  bannerBgName: Rustan Håkansson
  bannerBgPosition: CEO at Winning Impact AB
---
