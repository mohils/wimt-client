---
title: navbar
logo: /upload/images/logo.svg
navItem1: Home
navItem2: Team
button: Apply to sponsor
---
