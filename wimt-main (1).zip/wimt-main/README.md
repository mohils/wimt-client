# wimt

- Figma: <https://www.figma.com/file/sj1FBKYzMeUZxl0fMbsmVQ/WIMT-New-website?node-id=0%3A1&t=uIctehx0pjc5zGCM-0>

- frontend: <https://wimt-client.netlify.app>
- admin: <https://wimt-client.netlify.app/admin>
